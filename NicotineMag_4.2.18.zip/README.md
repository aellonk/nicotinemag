# nicotinemag
nicotine is a biannual fashion and art magazine based in new york
